import React from 'react';
import '../css/default.css';
import '../css/mainAdmin.css';
import MainAdmin from './MainAdmin';

function Admin() {
    return (
      <>
      
            
            <MainAdmin />
              {/* 다른 경로들도 여기 추가할 수 있습니다. */}
    
    </>
    );
  }
  
  export default Admin;