const ReservationsAdmin = () => {
    return (
        <h1>예약 관리 메뉴다</h1>
    );
}

export default ReservationsAdmin;